close all;
clear;
clc;

%It can be selected the size of the macroblocks
mbSize = 32;

%Frame number 1
f0 = ones(256, 256,3);
%Green square
k=0;
f0(1+k:32+k,33+k:64+k,1)=0;
f0(1+k:32+k,33+k:64+k,2)=1;
f0(1+k:32+k,33+k:64+k,3)=0;
%Red square
k=32;
f0(1+k:32+k,33+k:64+k,1)=1;
f0(1+k:32+k,33+k:64+k,2)=0;
f0(1+k:32+k,33+k:64+k,3)=0;
%Black square
k=128;
f0(1+k:32+k,33+k:64+k,1)=0;
f0(1+k:32+k,33+k:64+k,2)=0;
f0(1+k:32+k,33+k:64+k,3)=0;
%Cyan square
k=128;
f0(1+k:32+k,33:64,1)=0;
f0(1+k:32+k,33:64,2)=1;
f0(1+k:32+k,33:64,3)=1;

hf = figure;
set(hf, 'position', [100 300 256 256]);
imshow(f0);
%It draws a black grid on the frame
hold on
M = size(f0,1);
N = size(f0,2);
        for k = 1:mbSize:M+1
            x = [1 N];
            y = [k k];
            plot(x,y,'Color','k','LineStyle','-');
        end
        for k = 1:mbSize:N+1
            x = [k k];
            y = [1 M];
            plot(x,y,'Color','k','LineStyle','-');
        end
hold off

%Frame number 2
f1 = ones(256, 256,3);
%Red square
k = 64;
f1(1+k:32+k,33+k:64+k,1)=1;
f1(1+k:32+k,33+k:64+k,2)=0;
f1(1+k:32+k,33+k:64+k,3)=0;
%Green square
k = 96;
l=32;
f1(1+k+l:32+k+l,33+k:64+k,1)=0;
f1(1+k+l:32+k+l,33+k:64+k,2)=1;
f1(1+k+l:32+k+l,33+k:64+k,3)=0;
%Cyan square
f1(1:32,1:32,1)=0;
f1(1:32,1:32,2)=1;
f1(1:32,1:32,3)=1;
%Black square
k=160;
f1(1+k:32+k,33:64,1)=0;
f1(1+k:32+k,33:64,2)=0;
f1(1+k:32+k,33:64,3)=0;

hf2 = figure;
set(hf2, 'position', [500 300 256 256]);
imshow(f1);
%It draws a black grid on the frame
hold on
M = size(f1,1);
N = size(f1,2);
        for k = 1:mbSize:M+1
            x = [1 N];
            y = [k k];
            plot(x,y,'Color','k','LineStyle','-');
        end
        for k = 1:mbSize:N+1
            x = [k k];
            y = [1 M];
            plot(x,y,'Color','k','LineStyle','-');
        end
hold off

waitforbuttonpress;

%Frame number 3 in which the results are drawn
hf3 = figure;
set(hf3, 'position', [900 300 256 256]);
imshow(f0);
hold on
[motionVect, EScomputations] = motionEstES_3channels(f1, f0, mbSize);
hold off
