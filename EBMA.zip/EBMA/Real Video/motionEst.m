% This function computes the motion vectors
%
% Input
%   anchor : The anchor frame
%   frame : The second frame
%   mbSize : Size of the macroblock
%   R: Parameter used to define the search region
%   stepSize: Step size used in the search phase
%
%
% Ouput
%   motionVect : the motion vectors for each macroblock in the anchor
%
% added by
% Emanuele Sansone GCNU 13/05/15

function motionVect = motionEst(anchor, frame, mbSize, R, stepSize)

[row, col, ~] = size(anchor);
maxR = row - mbSize + 1;
maxC = col - mbSize + 1;
computations = 0;
motionVect = [];

costs_1 = ones(row , col) * flintmax;
costs_2 = ones(row , col) * flintmax;
costs_3 = ones(row , col) * flintmax;

% Blocks in the anchor frame
for i = 1:mbSize:maxR
   for j = 1:mbSize:maxC
       center_i = i + floor(mbSize/2);
       center_j = j + floor(mbSize/2);
       start_l = center_i - stepSize;
       start_m = center_j - stepSize;
       stop_l = center_i + stepSize;
       stop_m = center_j + stepSize;
       
       if start_l <= 0
           start_l = 1;
       end
       
       if start_m <= 0
           start_m = 1;
       end
       
       if stop_l > maxR
          stop_l = maxR; 
       end
       
       if stop_m > maxC
          stop_m = maxC; 
       end
       
       
       %It calculates the matrix of costs for every macroblock
       for l = start_l:stepSize:stop_l
          for m = start_m:stepSize:stop_m
                %%%%MODIFY HERE%%%%%
                
                
                
                computations = computations + 1;          
          end
       end
       
        [dx, dy, min] = minCost(costs, i, j); 
        
        % Adding a grid
        M = size(anchor,1);
        N = size(anchor,2);
        for k = 1:mbSize:M+1
            x = [1 N];
            y = [k k];
            plot(x,y,'Color','k','LineStyle','-');
        end
        for k = 1:mbSize:N+1
            x = [k k];
            y = [1 M];
            plot(x,y,'Color','k','LineStyle','-');
        end
        
        %It draws the results on the anchor frame
        if (dx == i && dy == j)
            line([j+(mbSize/2) j+(mbSize/2)], [i+(mbSize/2) i+(mbSize/2)], 'Marker', 'x', 'MarkerSize', 5 , 'Color','b');
        else
            quiver( j+(mbSize/2),i+(mbSize/2),j-dy,i-dx,'Color','b','LineWidth',2);
        end
        
        costs_1 = ones(row , col) * flintmax;
        costs_2 = ones(row , col) * flintmax;
        costs_3 = ones(row , col) * flintmax;

        motionVect = [motionVect; [ dy - j, dx - i ]];
   end
end

fprintf('Number of comparisons: %d\n', computations);

