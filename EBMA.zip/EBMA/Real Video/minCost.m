% This function finds the coordinates and the value of the cell that holds the minimum cost
%
% Input
%   costs : the matrix that contains the estimation costs for a macroblock
%   x : the col (horizontal) macroblock index
%   y : the row (vertical) macroblock index
%
% Output
%   dx : the motion vector component in columns
%   dy : the motion vector component in rows
%   min : the value of the minimum cost
%

function [dx, dy, min] = minCost(costs, x, y)

[row, col] = size(costs);
n = 1;
min = flintmax;
D_min = flintmax;

for i = 1:row
    for j = 1:col
        if (costs(i,j) < min)
            min = costs(i,j);
        end
    end
end

for i = 1:row
    for j = 1:col
        if (costs(i,j) == min)
            Array(n, 1) = i;
            Array(n, 2) = j;
            n = n+1;
        end
    end
end

for t = 1:n-1
    MV_norm = sqrt((x-Array(t, 1))^2 + (y-Array(t, 2))^2 );
    if ( MV_norm < D_min   )  
        dx = Array(t, 1);
        dy = Array(t, 2);
        D_min = sqrt((x-Array(t, 1))^2 + (y-Array(t, 2))^2); 
    end
end




