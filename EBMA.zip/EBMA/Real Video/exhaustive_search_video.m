close all;
clear;
clc;

%It can be selected the size of the macroblocks
mbSize = 13; % odd number
R = mbSize*1 + floor(mbSize/2);
stepSize = 1;

%It reads and extracts the informations from the movie file
video = VideoReader('stefan2400k.mp4');
get(video);
nFrames = video.NumberOfFrames;
vidHeight = video.Height;
vidWidth = video.Width;

%Preallocate movie structure.
mov1(1:nFrames) = struct('cdata', zeros(vidHeight, vidWidth, 3, 'uint8'), 'colormap', []);


%It selects the first extracted frame
f0 = read(video,1);
hf = figure;
set(hf, 'position', [0 300 vidWidth vidHeight]);
imshow(f0);

%It draws a black grid on the frame
hold on
M = size(f0,1);
N = size(f0,2);
for k = 1:mbSize:M+1
    x = [1 N];
    y = [k k];
    plot(x,y,'Color','k','LineStyle','-');
end
for k = 1:mbSize:N+1
    x = [k k];
    y = [1 M];
    plot(x,y,'Color','k','LineStyle','-');
end
hold off


%%It selects the second extracted frame 
f1 = read(video,2);
hf = figure;
set(hf, 'position', [400 300 vidWidth vidHeight]);
imshow(f1);

%It draws a black grid on the frame
hold on
M = size(f1,1);
N = size(f1,2);
for k = 1:mbSize:M+1
    x = [1 N];
    y = [k k];
    plot(x,y,'Color','k','LineStyle','-');
end
for k = 1:mbSize:N+1
    x = [k k];
    y = [1 M];
    plot(x,y,'Color','k','LineStyle','-');
end
hold off

%waitforbuttonpress;

%It selects the second frame extracted in which the results will be drawn
% hf = figure;
% set(hf, 'position', [800 300 vidWidth vidHeight])
% imshow(f0);
% hold on
% motionVect = motionEst(f0, f1, mbSize, R, stepSize);
% hold off