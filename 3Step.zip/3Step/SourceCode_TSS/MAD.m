function v_distance = MAD(Block_A, Block_B)

v_distance = sum(sum(abs(Block_A-Block_B)));
