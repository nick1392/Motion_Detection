function [r, c] = find_min_distance(v_distance)

val_min = min(min(v_distance));
[temp_r, temp_c] = find(v_distance == val_min);
r = temp_r(1);
c = temp_c(1);