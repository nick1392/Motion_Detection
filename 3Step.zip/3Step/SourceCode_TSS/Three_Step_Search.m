close all;
clear all;
clc;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CONFIGURATION PARAMS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
filenameOrig='../Stefan_rid.yuv';% here you have to specify the address of the original video sequence.

input=0; % 0 = YUV420
         % 1 = YUV444

nFrames=50; %number fo frames you want to code.

numR=288;
numC=352;

numROut = 288;
numCOut = 352;

ratioR = numR/numROut;
ratioC = numC/numCOut;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% END CONFIG
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fnameOut=[filenameOrig(1:end-4) '_to_' int2str(numCOut) 'x' int2str(numROut) '.yuv'];

% Open File to Read
fy=fopen(filenameOrig,'rb');
fp=fopen(filenameOrig,'rb');

% Open Files to Write
fout=fopen(fnameOut,'wb');
fErr=fopen('ImmErr.yuv','wb');
fDiff=fopen('ImmDiff.yuv','wb');

% R reads frame N+1, Y reads frame N  
if (input)
   R = fread(fp,3*numR*numC,'uint8',0);
else
   R = fread(fp,(3/2)*numR*numC,'uint8',0);
end    

for k=1:nFrames-1
    k
    Y = fread(fy,numR*numC,'uint8',0);
    Y = imresize(reshape(Y, numC, numR)', [numROut numCOut]);
    R = fread(fp,numR*numC,'uint8',0);
    R = imresize(reshape(R, numC, numR)', [numROut numCOut]);
    D = R-Y;
    if(input)
        U = fread(fy,numR*numC,'uint8',0);
        U = imresize(reshape(U, numC, numR)', [numROut/2 numCOut/2]);
        V = fread(fy,numR*numC,'uint8',0);
        V = imresize(reshape(V, numC, numR)', [numROut/2 numCOut/2]);
        Up = fread(fp,numR*numC,'uint8',0);
        Up = imresize(reshape(Up, numC, numR)', [numROut/2 numCOut/2]);
        Vp = fread(fp,numR*numC,'uint8',0);
        Vp = imresize(reshape(Vp, numC, numR)', [numROut/2 numCOut/2]);
    else
        U = fread(fy,numR*numC/4,'uint8',0);
        U = imresize(reshape(U, numC/2, numR/2)', [numROut/2 numCOut/2]);
        V = fread(fy,numR*numC/4,'uint8',0);
        V = imresize(reshape(V, numC/2, numR/2)', [numROut/2 numCOut/2]);
        Up = fread(fp,numR*numC/4,'uint8',0);
        Up = imresize(reshape(Up, numC/2, numR/2)', [numROut/2 numCOut/2]);
        Vp = fread(fp,numR*numC/4,'uint8',0);
        Vp = imresize(reshape(Vp, numC/2, numR/2)', [numROut/2 numCOut/2]);
    end
    
    
    % Memory allocation
    
    % Motion Block (MB) size 
    MB_size = 8;
    
    % MC_Image: Motion compensated image
    MC_Image = zeros(numR, numC);
    % Error_Immage
    Error_Image = zeros(numR, numC);
    % MotionVector: Motion_Vector Matrix
    MotionVector = zeros(2, numR*numC/MB_size^2);
    % Distance: 3x3 matrix storing the 9 points selected by the 3Step algorithm
    Distance = ones(3,3)*2^15;
        
    % Max number of MB
    MaxR = numR-MB_size+1;
    MaxC = numC-MB_size+1;
    
    % Matrix storing the position of MBs
    c=1;
    for i=MaxR:-MB_size:1
        for j=1:MB_size:MaxC
            MB_pos(1,c)=j+floor((MB_size-1)/2);
            MB_pos(2,c)=i+floor((MB_size-1)/2);
            c=c+1;
        end
    end
    
    % Compute Step Max
    Range = 7; % Range dispari 3, 7, 15..
    Step_max=floor(Range/2)+1;
    
    % starting form the first MB
    num_MB = 1;
    
    % Search for every MB in the frame
    
    % Rows
    for i=1:MB_size:MaxR
        % Columns
        for j=1:MB_size:MaxC
            
            x = j;
            y = i;
            
            % Compute error in the search window between original and
            % current frame.
            Distance(2,2) = MAD(Y(i:i+MB_size-1,j:j+MB_size-1), R(i:i+MB_size-1,j:j+MB_size-1));
            
            % Maximum step size for first iteration
            Step_size = Step_max;
            
            index = 1;
            % Three Steps of research%%%%%%%%%%%%%%%
            while (index <= 3)   
            

                
            end
            
            MotionVector(1, num_MB) = y-i;
            MotionVector(2, num_MB) = x-j;
            
%             y_coor = MotionVector(1, num_MB);
%             x_coor = MotionVector(2, num_MB);
%             Index_ver = i + y_coor;
%             Index_or = j + x_coor;
%               Index_ver = y;
%               Index_or = x;
              MC_Image(i:i+MB_size-1,j:j+MB_size-1) = R(y:y+MB_size-1, x:x+MB_size-1);
            
            % Start again for a new macroblock
            num_MB = num_MB+1;
            Distance = ones(3,3)*2^15;
        end
    end
    hf = figure(1);
    set(hf, 'position', [200 300 numC numR]);
    MVs=quiver(MB_pos(1,:),MB_pos(2,:),MotionVector(2,:),MotionVector(1,:));
    
    
    Y_col = reshape(Y,size(Y,1)*size(Y,2),1);
    U_col = zeros(size(Y,1),size(Y,2));
    V_col = zeros(size(Y,1),size(Y,2));
    if(input)
        U_col = reshape(U,size(U,1)*size(U,2),1);
        V_col = reshape(V,size(V,1)*size(V,2),1);
    else
        % Bilinear interpolation
        for i = 1:numR
           for j = 1:numC
              if rem(i,2)*rem(j,2) ~= 0
                 U_col(i,j) = U(((i-1)/2)+1,((j-1)/2)+1);
                 V_col(i,j) = V(((i-1)/2)+1,((j-1)/2)+1);                                          
              end
           end
        end
        for i = 1:numR
           for j = 1:numC
              if rem(i,2)*rem(j,2) == 0
                  if rem(i,2) == rem(j,2)
                       if i ~= numR && j ~= numC 
                         U_col(i,j) = (U(i/2,j/2)+U(i/2+1,j/2)+U(i/2,j/2+1)+U(i/2+1,j/2+1))/4;
                         V_col(i,j) = (V(i/2,j/2)+V(i/2+1,j/2)+V(i/2,j/2+1)+V(i/2+1,j/2+1))/4;
                       end
                  else
                     if rem(i,2) == 0
                        if i ~= numR && j ~= numC 
                             U_col(i,j) = (U(i/2,((j-1)/2)+1)+U(i/2+1,((j-1)/2)+1))/2;
                             V_col(i,j) = (V(i/2,((j-1)/2)+1)+V(i/2+1,((j-1)/2)+1))/2;  
                        end
                     else
                         if i ~= numR && j ~= numC 
                             U_col(i,j) = (U(((i-1)/2)+1,j/2)+U(((i-1)/2)+1,j/2+1))/2;
                             V_col(i,j) = (V(((i-1)/2)+1,j/2)+V(((i-1)/2)+1,j/2+1))/2;
                         end
                     end
                  end
              end
           end
        end
    end
    frame(:,:,1) = Y./max(max(Y));
    frame(:,:,2) = U_col./max(max(Y));
    frame(:,:,3) = V_col./max(max(Y));
    rgbmap = ycbcr2rgb(frame);
        
    hf2 = figure(2);
    set(hf2, 'position', [800 300 numC numR]);
    imshow(rgbmap);
    axis ([-10 360 -10 300]);
    title(sprintf('%d',k));
    figure(1);
    M(k)=getframe(gcf); % get current figure
    Error_Image = Y-MC_Image;
    hf3 = figure(3);
    imshow(Error_Image);
   
end

fclose('all');